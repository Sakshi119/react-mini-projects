

import { useState } from "react";
const emptyHeartImage = "https://i.imgur.com/wIq3Wbq.png";
const fullHeartImage = "https://i.imgur.com/vyX9Vnx.png";
const LikeButton = () => {
    const [likes, setLikes] = useState(0);
    
    return (
        <div className="like-info">
            <div className="like-button" onClick={()=>setLikes(likes+1)}>
                {likes > 0 ? (
                    <img src={fullHeartImage} alt="Heart for the like button"/>
                ):(
                    <img src={emptyHeartImage} alt="Empty Heart for the like button"/>
                )}
            </div>
            <p>{likes == 1 ? `${likes} Like` : `${likes} Likes`}</p>
        </div>
    )
}

export default LikeButton