import FollowButton from './FollowButton';
import LikeButton from './LikeButton';


const postImage = "https://i.pinimg.com/736x/08/e0/85/08e0850de8682a9214721079015969b5.jpg";
const userImage = "https://i.pinimg.com/736x/b9/b9/fb/b9b9fbf45fd39537d599e5e39be34020.jpg";


const Post = () => {
  return (
    <div className='post'>
        <div className='user-info'>
            <img id="profile-img" src={userImage} alt="Profile Image" />
            <p>PandaTheMeow</p>
            <FollowButton />
        </div>
        <img id="post-img" src={postImage} alt='Post Image'/>
        <LikeButton />
    </div>
  )
}

export default Post